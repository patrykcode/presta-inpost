<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_e013f5f6bd49cb9cc7a09efe8ea4a5db'] = 'Witaj';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_cb6324cbf2e522d7d267729e37f65e71'] = 'Twój produkt już jest na stanie!';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_9e5c8c4c9e5472d38a5ced5d12bc1b90'] = 'Wiadomość';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_d8182f52f358bd4c1870eef3963da4eb'] = 'Przejdź do produktu';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_63ef50cc53f0d953193e481e92340cb7'] = 'Lista';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_c905f4526b369c66711d6d4e97305b1d'] = 'Powiadomiony';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_0c83f57c786a0b4a39efab23731c7ebc'] = 'email';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_acb4d1b2163378ed51e7fe69eda71843'] = 'nazwa';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_71e48fab9f293e9b1cfb2bc8769df351'] = 'dodany';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_3b23eb2bb9d36b338d3742d9cf29dd24'] = 'Powiadomienie o dostępności!';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_0a2dc9d01b9630beac483a3228ea2d6d'] = 'Powiadom mnie o dostępności';
$_MODULE['<{rediconoutofstock}prestashop>rediconoutofstock_d0c7cf689ff625ecaf81b0d3afba4079'] = 'zatwierdz';
